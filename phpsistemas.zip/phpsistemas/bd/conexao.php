<?php
// Defina suas credenciais de conexão
$host = 'localhost';      // Host do MySQL
$db = 'imovelbdnovo2';      // Nome do banco de dados que você criou
$user = 'root';          // Nome de usuário do MySQL (padrão no XAMPP)
$password = '';          // Senha do MySQL (normalmente vazia no XAMPP)

// Tente estabelecer a conexão
try {
    // Criar uma nova conexão PDO
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $password);
    // Definir o modo de erro do PDO para exceções
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão com o banco de dados: " . $e->getMessage());
}
?>
