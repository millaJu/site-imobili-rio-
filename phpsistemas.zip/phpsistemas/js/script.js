function listarImoveis() {
    fetch('../controllers/ImovelController.php?action=listar')
        .then(response => response.json())
        .then(data => {
            let imoveisList = document.getElementById('imoveisList');
            imoveisList.innerHTML = '';
            data.forEach(imovel => {
                imoveisList.innerHTML += `
                    <li>
                        <h5>${imovel.titulo}</h5>
                        <p>${imovel.descricao}</p>
                        <button onclick="editarImovel(${imovel.id})">Editar</button>
                        <button onclick="excluirImovel(${imovel.id})">Excluir</button>
                    </li>
                `;
            });
        });
}

function cadastrarImovel() {
    const formData = new FormData(document.getElementById('cadastrarForm'));

    fetch('../controllers/ImovelController.php?action=cadastrar', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            alert('Imóvel cadastrado com sucesso!');
            window.location.href = 'index.html'; // Redireciona para a lista de imóveis
        } else {
            alert('Erro ao cadastrar o imóvel: ' + data.message);
        }
    })
    .catch(error => console.error('Erro ao cadastrar imóvel:', error));
}

function editarImovel(id) {
    fetch(`../controllers/ImovelController.php?action=editar&id=${id}`, {
        method: 'POST',
        body: JSON.stringify({
            titulo: 'Novo Título',  // Obter valores dos campos do formulário
            descricao: 'Nova Descrição',
            preco: 150000,
            endereco: 'Novo Endereço',
            area: 100,
            quartos: 2,
            banheiros: 1,
            garagem: 1,
            imagem: 'nova_imagem.jpg'
        }),
        headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            listarImoveis();
        }
    });
}

function excluirImovel(id) {
    if (confirm('Tem certeza que deseja excluir este imóvel?')) {
        fetch(`../controllers/ImovelController.php?action=excluir&id=${id}`, {
            method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                listarImoveis();
            }
        });
    }
}
function obterDetalhesImovel(id) {
    fetch(`../controllers/ImovelController.php?action=detalhes&id=${id}`)
        .then(response => response.json())
        .then(data => {
            const imovelDetalhes = document.getElementById('imovelDetalhes');
            imovelDetalhes.innerHTML = `
                <h2>${data.titulo}</h2>
                <p><strong>Descrição:</strong> ${data.descricao}</p>
                <p><strong>Preço:</strong> R$ ${data.preco}</p>
                <p><strong>Endereço:</strong> ${data.endereco}</p>
                <p><strong>Área:</strong> ${data.area} m²</p>
                <p><strong>Quartos:</strong> ${data.quartos}</p>
                <p><strong>Banheiros:</strong> ${data.banheiros}</p>
                <p><strong>Garagem:</strong> ${data.garagem ? 'Sim' : 'Não'}</p>
                <img src="../assets/images/${data.imagem}" alt="Imagem do imóvel">
            `;
        })
        .catch(error => console.error('Erro ao obter detalhes do imóvel:', error));
}

