<?php
header("Content-Type: application/json");
require_once 'conexao.php'; // Conexão com o banco de dados

$pdo = new PDO("mysql:host=localhost;dbname=imovelbdnovo2", "root", "");

$action = $_GET['action'] ?? '';

switch ($action) {
    // Outras ações...

    case 'cadastrar':
        $dados = json_decode(file_get_contents('php://input'), true);

        // Verifique se a imagem foi enviada
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../assets/images/';
            $uploadFile = $uploadDir . basename($_FILES['imagem']['name']);

            // Move a imagem para o diretório de upload
            if (move_uploaded_file($_FILES['imagem']['tmp_name'], $uploadFile)) {
                // Prepare os dados para o banco de dados
                $stmt = $pdo->prepare("INSERT INTO imovel (titulo, descricao, preco, endereco, area, quartos, banheiros, garagem, imagem) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $dados['titulo'], $dados['descricao'], $dados['preco'], $dados['endereco'],
                    $dados['area'], $dados['quartos'], $dados['banheiros'], $dados['garagem'],
                    basename($_FILES['imagem']['name'])
                ]);

                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Erro ao fazer upload da imagem.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Imagem não enviada ou ocorreu um erro.']);
        }
        break;

    default:
        echo json_encode(['error' => 'Ação inválida']);
}
?>