<?php
require_once 'bd/conexao.php'; // Inclua o arquivo de conexão

// Verifica se a conexão foi bem-sucedida
if (isset($pdo)) {
    echo "Conexão ao banco de dados realizada com sucesso!";
} else {
    echo "Falha na conexão ao banco de dados.";
}
?>
